WEBSITE QUÀ TÌNH YÊU DÀNH CHO VŨ MINH HÙNG 🤍

CÁCH XEM TRÊN MÁY:
1. Giải nén file qua_tinh_yeu_hung.zip.
2. Mở index.html bằng trình duyệt (Safari/Chrome).
3. Bấm “Mở món quà của em”, sau đó chọn từng điều bất ngờ.
4. Nhạc không tự phát. Bấm nút “Bật nhạc cho món quà” để nghe giai điệu piano được tạo ngay trong trình duyệt.

CÁCH ĐĂNG LÊN MẠNG LẤY LINK MIỄN PHÍ (GitHub Pages):
1. Đăng nhập hoặc tạo tài khoản tại https://github.com
2. Tạo repository mới, ví dụ tên: qua-tinh-yeu-hung
3. Đặt repository ở chế độ Public, bấm Create repository.
4. Chọn Add file → Upload files, tải lên file index.html (có thể tải cả README.md).
5. Bấm Commit changes.
6. Vào Settings → Pages.
7. Trong mục Build and deployment, chọn Deploy from a branch.
8. Chọn branch main và folder /(root), bấm Save.
9. Chờ vài phút, GitHub sẽ hiện website ở dạng:
   https://TEN-TAI-KHOAN.github.io/qua-tinh-yeu-hung/
   Thay TEN-TAI-KHOAN bằng tên tài khoản GitHub của bạn.
10. Mở link thử trên điện thoại trước khi gửi cho Hùng.

LƯU Ý:
- Không cần tải file nhạc riêng; giai điệu piano được tạo bằng Web Audio API.
- Nếu muốn thay lời nhắn, mở index.html bằng trình soạn thảo văn bản và sửa nội dung trong các phần article.
- Link GitHub Pages thường công khai cho bất kỳ ai có link/tìm được trang; đừng đưa thông tin riêng tư nhạy cảm vào website.
